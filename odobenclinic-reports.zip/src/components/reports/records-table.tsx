"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatPatientDisplayId, formatReportDate } from "@/lib/reporting";
import { hourOf, placeLabel } from "@/lib/reports/analytics";
import { loadDayDetails } from "@/lib/reports/loader";
import type { PatientRecord, RecordKind, VisitRecord } from "@/lib/reports/types";
import type { ReportRow } from "@/types/report";

type Rec = VisitRecord | PatientRecord;
type SortKey = "date" | "pid" | "age" | "sex" | "area";

const selectClass = "h-11 rounded-md border border-border bg-background px-3 text-sm";

/**
 * Names are not kept in the saved data, so only the rows on screen are looked up
 * (one request per date shown, remembered for the rest of the session).
 */
export function RecordsTable({ kind, records }: { kind: RecordKind; records: Rec[] }) {
  const [sortKey, setSortKey] = useState<SortKey>("date");
  const [dir, setDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [search, setSearch] = useState("");

  const sorted = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = q ? records.filter((r) => formatPatientDisplayId(r.pid).toLowerCase().includes(q)) : records;
    const sign = dir === "asc" ? 1 : -1;
    const value = (r: Rec) => (sortKey === "age" ? r.age ?? -1 : sortKey === "area" ? r.area : sortKey === "sex" ? r.sex : sortKey === "pid" ? r.pid : r.date);
    return [...list].sort((a, b) => {
      const x = value(a), y = value(b);
      const c = typeof x === "number" && typeof y === "number" ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true });
      return c !== 0 ? sign * c : a.pid.localeCompare(b.pid);
    });
  }, [records, search, sortKey, dir]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const current = Math.min(page, totalPages);
  const pageRows = sorted.slice((current - 1) * pageSize, current * pageSize);
  const dates = useMemo(() => [...new Set(pageRows.map((r) => r.date))], [pageRows]);

  const { data: details, isFetching } = useQuery({
    queryKey: ["rpt-details", kind, dates.join(",")],
    enabled: dates.length > 0,
    staleTime: 5 * 60_000,
    refetchOnWindowFocus: false,
    queryFn: async ({ signal }) => {
      const map = new Map<string, ReportRow[]>();
      for (let i = 0; i < dates.length; i += 4) {
        const chunk = dates.slice(i, i + 4);
        const loaded = await Promise.all(chunk.map((d) => loadDayDetails(kind, d, signal)));
        chunk.forEach((d, j) => map.set(d, loaded[j]));
      }
      return map;
    },
  });

  const detailRows = useMemo(() => {
    const used = new Map<string, number>();
    return pageRows.map((r) => {
      const key = `${r.date}|${r.pid}`;
      const n = used.get(key) ?? 0;
      used.set(key, n + 1);
      const candidates = (details?.get(r.date) ?? []).filter((x) => x.patientId === r.pid);
      return candidates[n] ?? candidates[0] ?? null;
    });
  }, [pageRows, details]);

  const sortBy = (key: SortKey) => {
    if (key === sortKey) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setDir(key === "date" ? "desc" : "asc"); }
  };
  const Head = ({ id, label }: { id: SortKey; label: string }) => (
    <th className="px-3 py-1 font-semibold">
      <button type="button" onClick={() => sortBy(id)} className="inline-flex min-h-11 items-center gap-1 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
        {label}{sortKey === id ? (dir === "asc" ? <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" /> : <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />) : null}
      </button>
    </th>
  );
  const nameOf = (d: ReportRow | null) => d?.name ?? (isFetching ? "…" : "—");
  const dateLabel = (r: Rec) => formatReportDate(r.date);
  const typeLabel = (r: Rec) => ("type" in r ? r.type : "");
  const timeLabel = (r: Rec) => { const h = "at" in r ? hourOf(r.at) : null; return h === null ? "" : `${String(h).padStart(2, "0")}:${String((r as VisitRecord).at?.slice(14, 16) ?? "00")}`; };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <input
          type="search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="Find an OPD number" aria-label="Find an OPD number"
          className="h-11 w-full rounded-md border border-border bg-background px-3 text-sm sm:w-64"
        />
        <label className="flex items-center gap-2 text-sm text-muted-foreground">
          Rows per page
          <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} className={selectClass}>
            {[20, 50, 100].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </label>
      </div>

      {sorted.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No records match the current period and filters.</div>
      ) : (
        <>
          <div className="hidden overflow-x-auto md:block">
            <table className="min-w-full text-left text-sm">
              <thead className="border-b border-border">
                <tr>
                  <Head id="pid" label="OPD No." />
                  <th className="px-3 py-1 font-semibold">Name</th>
                  <Head id="age" label="Age" />
                  <Head id="sex" label="Sex" />
                  <Head id="area" label="Area" />
                  <Head id="date" label={kind === "visits" ? "Visit date" : "Registered"} />
                  {kind === "visits" ? <th className="px-3 py-1 font-semibold">Type</th> : null}
                </tr>
              </thead>
              <tbody>
                {pageRows.map((r, i) => (
                  <tr key={`${r.pid}-${r.date}-${i}`} className="border-b border-border last:border-0">
                    <td className="px-3 py-3 font-mono text-xs">{formatPatientDisplayId(r.pid)}</td>
                    <td className="max-w-64 break-words px-3 py-3">{nameOf(detailRows[i])}</td>
                    <td className="px-3 py-3 tabular-nums">{r.age ?? "—"}</td>
                    <td className="px-3 py-3 capitalize">{r.sex === "other" ? "—" : r.sex}</td>
                    <td className="px-3 py-3">{placeLabel(r.area)}</td>
                    <td className="px-3 py-3">{dateLabel(r)} {timeLabel(r)}</td>
                    {kind === "visits" ? <td className="px-3 py-3 capitalize">{typeLabel(r)}</td> : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <ul className="space-y-2 md:hidden">
            {pageRows.map((r, i) => (
              <li key={`${r.pid}-${r.date}-${i}`} className="rounded-xl border border-border bg-background p-4">
                <p className="break-words font-medium text-foreground">{nameOf(detailRows[i])}</p>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  <span className="font-mono text-xs">{formatPatientDisplayId(r.pid)}</span> · {r.age ?? "—"} yrs · <span className="capitalize">{r.sex === "other" ? "sex not recorded" : r.sex}</span>
                </p>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {placeLabel(r.area)} · {dateLabel(r)} {timeLabel(r)}{kind === "visits" ? ` · ${typeLabel(r)}` : ""}
                </p>
              </li>
            ))}
          </ul>
        </>
      )}

      {sorted.length > 0 ? (
        <div className="sticky bottom-0 mt-4 flex items-center justify-between gap-3 border-t border-border bg-card py-2 text-sm text-muted-foreground md:static md:border-0 print:hidden">
          <span>{sorted.length.toLocaleString()} records, page {current} of {totalPages}</span>
          <div className="flex gap-2">
            <Button type="button" variant="secondary" className="min-h-11" disabled={current <= 1} onClick={() => setPage(current - 1)}>Previous</Button>
            <Button type="button" variant="secondary" className="min-h-11" disabled={current >= totalPages} onClick={() => setPage(current + 1)}>Next</Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
